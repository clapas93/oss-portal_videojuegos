$(document).ready(function(){
    
$("input[name=creditOptions][id=FREE]").click(function(){
    var related_class=$(this).val();
    $('.'+related_class).prop('disabled',true);
    $('.'+related_class).prop('placeholder',"0");
});


$("input[name=creditOptions][id=CREDIT]").click(function(){
    var related_class=$(this).val();
    $('.'+related_class).prop('disabled',false);
});


$('#gameForm').validate({   
    rules: {
        TITLE:{
            minlength: 3,
            //maxlength: 15,
            required: true
        }
        
    },
    messages:{
        TITLE:{
            minlength: "El título debe de ser mayor a 3 caracteres",
            required: "Inserta un título para el videojuego"
        }
    },
    highlight: function(element) {
            $(element).closest('.form-group').addClass('has-error');
   },
    unhighlight: function(element) {
            $(element).closest('.form-group').removeClass('has-error');
    },
    errorElement: 'span',
    errorClass: 'help-block',
    errorPlacement: function(error, element) {
        if(element.parent('.input-group').length) {
            error.insertAfter(element.parent());
        } else {
            error.insertAfter(element);
        }
    }
});

//$('gameForm').validator()


});
